<?php 
    $koneksi = mysqli_connect('localhost', 'root', '', 'petshop') or die ('unable koneksi');

    // $koneksi = mysqli_connect('localhost', 'u1575378_bukutamu', 'aplikasibukutamu', 'u1575378_buku_tamu') or die ('unable koneksi');
?>
